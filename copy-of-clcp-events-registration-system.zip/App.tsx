
import React, { useState, useMemo, useEffect } from 'react';
import { 
  RegistrationStep, 
  ContactData, 
  AttendanceType, 
  SessionType, 
  RegistrationRecord 
} from './types';
import { 
  lookupContact, 
  saveToEvents1, 
  getAllRegistrations, 
  verifyAttendance,
  clearAllData,
  checkExistingRegistration
} from './services/geminiService';
import { 
  EnvelopeIcon, 
  UserIcon, 
  DevicePhoneMobileIcon, 
  CheckCircleIcon,
  ArrowRightIcon,
  TableCellsIcon,
  PencilSquareIcon,
  LockClosedIcon,
  ExclamationCircleIcon,
  MagnifyingGlassIcon,
  ArrowDownTrayIcon,
  ArrowPathIcon,
  TrashIcon,
  InformationCircleIcon,
  PencilIcon
} from '@heroicons/react/24/outline';

const ACCESS_CODE = 'CLCP-SEC-2024';

const App: React.FC = () => {
  const [view, setView] = useState<'form' | 'admin'>('form');
  const [step, setStep] = useState<RegistrationStep>(RegistrationStep.EMAIL_INPUT);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);
  
  // Form State
  const [email, setEmail] = useState('');
  const [contact, setContact] = useState<ContactData | null>(null);
  const [existingRecord, setExistingRecord] = useState<RegistrationRecord | null>(null);
  const [manualName, setManualName] = useState('');
  const [manualPhone, setManualPhone] = useState('');
  const [attendance, setAttendance] = useState<AttendanceType>('');
  const [session, setSession] = useState<SessionType>('');
  
  // Admin State
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [authInput, setAuthInput] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [allRecords, setAllRecords] = useState<RegistrationRecord[]>([]);

  // Update records when view changes or after a successful save
  useEffect(() => {
    setAllRecords(getAllRegistrations());
  }, [view, step]);

  const filteredRecords = useMemo(() => {
    return allRecords.filter(r => 
      r.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      r.email.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [allRecords, searchTerm]);

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setExistingRecord(null);
    setContact(null);
    setIsUpdating(false);
    
    try {
      // 1. Check if already in Events1 spreadsheet
      const existing = await checkExistingRegistration(email);
      if (existing) {
        setExistingRecord(existing);
        setStep(RegistrationStep.ALREADY_REGISTERED);
        // Pre-fill for potential update
        setAttendance(existing.attendance);
        setSession(existing.session);
        return;
      }

      // 2. If not, check secretariat@clcphilippines.org contacts
      const found = await lookupContact(email);
      if (found) {
        setContact(found);
        setStep(RegistrationStep.VERIFY_CONTACT);
      } else {
        setStep(RegistrationStep.MANUAL_ENTRY);
      }
    } catch (err) {
      setError("Database connection error.");
    } finally {
      setLoading(false);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualName || !manualPhone) return;
    setStep(RegistrationStep.PREFERENCES);
  };

  const handleStartUpdate = () => {
    setIsUpdating(true);
    setStep(RegistrationStep.PREFERENCES);
  };

  const handleSaveRegistration = async () => {
    setLoading(true);
    const finalName = existingRecord ? existingRecord.name : (contact ? contact.name : manualName);
    const finalPhone = existingRecord ? existingRecord.phone : (contact ? contact.phone : manualPhone);
    const finalDept = existingRecord ? existingRecord.departmentTitle : contact?.departmentTitle;
    
    const record: RegistrationRecord = {
      name: finalName,
      email: email.toLowerCase().trim(),
      phone: finalPhone,
      attendance,
      session,
      confirmation: existingRecord ? existingRecord.confirmation : 'N',
      id: existingRecord ? existingRecord.id : `REG-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
      timestamp: new Date().toISOString(),
      departmentTitle: finalDept
    };

    try {
      await saveToEvents1(record);
      setStep(RegistrationStep.SUCCESS);
    } catch (err) {
      setError("Failed to write to Events1.");
    } finally {
      setLoading(false);
    }
  };

  const handleSimulateVerification = async () => {
    setLoading(true);
    await verifyAttendance(email);
    setLoading(false);
    setAllRecords(getAllRegistrations());
    alert("Verification Successful! Sheet marked as 'Y'.");
  };

  const exportToCSV = () => {
    if (allRecords.length === 0) return;
    const headers = ["Name", "Email", "Phone", "Attendance", "Session", "Confirmation", "Timestamp"];
    const rows = allRecords.map(r => [
      r.name, r.email, r.phone, r.attendance, r.session, r.confirmation, r.timestamp
    ]);
    
    const csvContent = [
      headers.join(","),
      ...rows.map(row => row.map(val => `"${val}"`).join(","))
    ].join("\n");

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `CLCP_Events1_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleClearData = () => {
    if (confirm("Clear all records from Events1? This cannot be undone.")) {
      clearAllData();
      setAllRecords([]);
    }
  };

  const resetForm = () => {
    setStep(RegistrationStep.EMAIL_INPUT);
    setEmail('');
    setContact(null);
    setExistingRecord(null);
    setManualName('');
    setManualPhone('');
    setAttendance('');
    setSession('');
    setIsUpdating(false);
    setError(null);
  };

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (authInput === ACCESS_CODE) {
      setIsAuthorized(true);
      setAuthInput('');
    } else {
      alert("Invalid Secretariat Access Code.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      <nav className="bg-white border-b border-slate-200 px-6 py-4 sticky top-0 z-30 shadow-sm">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-900 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-lg">C</div>
            <div>
              <h1 className="text-lg font-black text-slate-900 leading-tight">CLCP Events</h1>
              <p className="text-[10px] text-blue-600 uppercase tracking-widest font-black">National Secretariat</p>
            </div>
          </div>
          <div className="flex gap-2 bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
            <button 
              onClick={() => setView('form')} 
              className={`px-5 py-2 rounded-xl text-xs font-black uppercase tracking-tighter transition-all ${view === 'form' ? 'bg-white text-blue-800 shadow-md ring-1 ring-slate-200' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Registration
            </button>
            <button 
              onClick={() => setView('admin')} 
              className={`px-5 py-2 rounded-xl text-xs font-black uppercase tracking-tighter transition-all ${view === 'admin' ? 'bg-white text-blue-800 shadow-md ring-1 ring-slate-200' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Events1 Sheet
            </button>
          </div>
        </div>
      </nav>

      <main className="flex-1 flex items-center justify-center p-6">
        {view === 'form' ? (
          <div className="max-w-md w-full">
            <div className="bg-white rounded-3xl shadow-[0_32px_64px_-16px_rgba(0,0,0,0.1)] border border-slate-100 overflow-hidden relative min-h-[420px] flex flex-col">
              {loading && (
                <div className="absolute inset-0 bg-white/90 backdrop-blur-md z-50 flex flex-col items-center justify-center transition-all duration-300">
                  <div className="w-14 h-14 border-4 border-blue-100 border-t-blue-700 rounded-full animate-spin mb-4" />
                  <p className="font-black text-blue-900 uppercase tracking-widest text-[10px]">Syncing with Secretariat...</p>
                </div>
              )}

              {step === RegistrationStep.EMAIL_INPUT && (
                <div className="p-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <h2 className="text-3xl font-black mb-2 text-slate-900 tracking-tight">Register.</h2>
                  <p className="text-slate-500 text-sm mb-10 leading-relaxed font-medium">Search for your record in the CLCP National Secretariat database.</p>
                  <form onSubmit={handleEmailSubmit} className="space-y-5">
                    <div className="relative">
                      <EnvelopeIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-300" />
                      <input 
                        type="email" 
                        required 
                        value={email} 
                        onChange={(e) => setEmail(e.target.value)} 
                        placeholder="your.email@domain.com" 
                        className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-600 focus:bg-white outline-none transition-all font-medium"
                      />
                    </div>
                    <button type="submit" className="w-full bg-blue-700 hover:bg-blue-800 text-white font-black py-4.5 rounded-2xl shadow-xl shadow-blue-200 active:scale-[0.98] transition-all flex items-center justify-center gap-3">
                      Start Application <ArrowRightIcon className="w-4 h-4" />
                    </button>
                  </form>
                  <div className="mt-10 p-5 bg-slate-50 rounded-2xl border border-slate-200 border-dashed">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2 text-center">Development Shortcut</p>
                    <button onClick={() => setEmail('member@clcp.org')} className="w-full text-xs text-blue-600 font-bold hover:underline">Use: member@clcp.org</button>
                  </div>
                </div>
              )}

              {step === RegistrationStep.ALREADY_REGISTERED && existingRecord && (
                <div className="p-10 animate-in zoom-in duration-500 text-center">
                  <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-inner">
                    <InformationCircleIcon className="w-12 h-12" />
                  </div>
                  <h2 className="text-3xl font-black mb-3 text-slate-900">Registered</h2>
                  <p className="text-slate-500 text-sm mb-8 font-medium">We found your record for **{existingRecord.name}**.</p>
                  
                  <div className="bg-slate-50 border border-slate-100 rounded-2xl p-6 text-left mb-8 space-y-2">
                    <div className="flex justify-between text-[10px] font-black uppercase text-slate-400"><span>Attendance</span><span className="text-blue-600">{existingRecord.attendance}</span></div>
                    <div className="flex justify-between text-[10px] font-black uppercase text-slate-400"><span>Session</span><span className="text-blue-600">{existingRecord.session}</span></div>
                  </div>

                  <div className="flex flex-col gap-3">
                    <button onClick={handleStartUpdate} className="w-full bg-blue-700 text-white font-black py-4.5 rounded-2xl shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2">
                      <PencilIcon className="w-4 h-4" /> Change My Choices
                    </button>
                    <button onClick={resetForm} className="w-full py-4 text-slate-400 text-[10px] font-black uppercase tracking-widest hover:text-slate-600 transition-colors">Not Me? Go Back</button>
                  </div>
                </div>
              )}

              {step === RegistrationStep.VERIFY_CONTACT && contact && (
                <div className="p-10 animate-in slide-in-from-right duration-500">
                  <h2 className="text-3xl font-black mb-8 text-slate-900">Found You.</h2>
                  <div className="bg-blue-50 border-2 border-blue-100 rounded-3xl p-8 mb-10 text-center relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-3">
                      <CheckCircleIcon className="w-6 h-6 text-blue-200" />
                    </div>
                    <p className="text-[10px] text-blue-600 font-black uppercase tracking-[0.2em] mb-3">Identity Verified</p>
                    <h3 className="text-2xl font-black text-slate-900">{contact.name}</h3>
                    <p className="text-slate-500 text-sm mt-1 font-bold">{contact.departmentTitle || 'CLCP Member'}</p>
                  </div>
                  <div className="flex flex-col gap-3">
                    <button onClick={() => setStep(RegistrationStep.PREFERENCES)} className="bg-blue-700 text-white font-black py-5 rounded-2xl shadow-xl hover:bg-blue-800 transition-all active:scale-95">Yes, This is Me</button>
                    <button onClick={() => setStep(RegistrationStep.MANUAL_ENTRY)} className="py-4 text-slate-400 font-bold text-xs uppercase tracking-widest hover:text-slate-600">Incorrect? Register Manually</button>
                  </div>
                </div>
              )}

              {step === RegistrationStep.MANUAL_ENTRY && (
                <div className="p-10 animate-in slide-in-from-right duration-500">
                  <h2 className="text-3xl font-black mb-2 text-slate-900">New Entry.</h2>
                  <p className="text-slate-500 text-sm mb-8 font-medium">Please provide your details for the Events1 datasheet.</p>
                  <form onSubmit={handleManualSubmit} className="space-y-5">
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">Full Name</label>
                      <input 
                        type="text" 
                        required 
                        value={manualName} 
                        onChange={(e) => setManualName(e.target.value)} 
                        placeholder="Juan Dela Cruz" 
                        className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-600 outline-none transition-all font-bold text-slate-700"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1 tracking-widest">Contact Number</label>
                      <input 
                        type="tel" 
                        required 
                        value={manualPhone} 
                        onChange={(e) => setManualPhone(e.target.value)} 
                        placeholder="09XX XXX XXXX" 
                        className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-600 outline-none transition-all font-bold text-slate-700"
                      />
                    </div>
                    <button type="submit" className="w-full bg-blue-700 text-white font-black py-4.5 rounded-2xl shadow-xl mt-4 active:scale-95 transition-all">Continue</button>
                  </form>
                </div>
              )}

              {step === RegistrationStep.PREFERENCES && (
                <div className="p-10 animate-in fade-in duration-500">
                  <h2 className="text-3xl font-black mb-2 text-slate-900">{isUpdating ? 'Update.' : 'Options.'}</h2>
                  <p className="text-slate-500 text-sm mb-8 font-medium leading-relaxed">Select your preferred mode of attendance and session slot.</p>
                  
                  <div className="space-y-8">
                    {/* Attendance - Drop Box */}
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Attendance Mode</label>
                      <div className="relative">
                        <select 
                          value={attendance} 
                          onChange={(e) => setAttendance(e.target.value as AttendanceType)}
                          className="w-full p-4.5 bg-slate-50 border-2 border-slate-100 rounded-2xl font-black text-slate-800 outline-none cursor-pointer hover:bg-slate-100 transition-all appearance-none pr-12 focus:border-blue-600"
                        >
                          <option value="" disabled>Choose Location...</option>
                          <option value="In Person">In Person</option>
                          <option value="Zoom">By Zoom</option>
                        </select>
                        <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none">
                          <ArrowPathIcon className="w-4 h-4 text-slate-300" />
                        </div>
                      </div>
                    </div>

                    {/* Session - Multiple Choice */}
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Session Choice</label>
                      <div className="grid grid-cols-1 gap-2.5">
                        {['AM Session', 'PM Session', 'Both Sessions'].map(s => (
                          <button 
                            key={s} 
                            onClick={() => setSession(s as SessionType)}
                            className={`w-full p-4.5 rounded-2xl border-2 font-black text-sm text-left transition-all relative ${session === s ? 'border-blue-700 bg-blue-50 text-blue-900 shadow-sm ring-1 ring-blue-100' : 'border-slate-100 bg-slate-50 text-slate-600 hover:bg-slate-100'}`}
                          >
                            {s}
                            {session === s && <CheckCircleIcon className="w-5 h-5 absolute right-4 top-1/2 -translate-y-1/2 text-blue-600" />}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button 
                      disabled={!attendance || !session} 
                      onClick={() => setStep(RegistrationStep.SUMMARY)}
                      className="w-full bg-blue-700 text-white font-black py-5 rounded-2xl shadow-xl mt-4 disabled:opacity-30 disabled:cursor-not-allowed transition-all active:scale-95"
                    >
                      Review Selection
                    </button>
                  </div>
                </div>
              )}

              {step === RegistrationStep.SUMMARY && (
                <div className="p-10 animate-in slide-in-from-bottom-8 duration-500">
                  <h2 className="text-3xl font-black mb-2 text-slate-900">Summary.</h2>
                  <p className="text-slate-500 text-sm mb-8 font-medium leading-relaxed">Please review your {isUpdating ? 'updated' : 'final'} details before submitting.</p>
                  
                  <div className="bg-slate-50 border-2 border-slate-100 rounded-3xl overflow-hidden mb-10 divide-y divide-slate-100 shadow-inner">
                    <div className="p-5 flex justify-between items-center">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Name</span>
                      <span className="text-sm font-black text-slate-900">{existingRecord ? existingRecord.name : (contact ? contact.name : manualName)}</span>
                    </div>
                    <div className="p-5 flex justify-between items-center bg-white/40">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Attendance</span>
                      <span className="text-sm font-black text-blue-700 uppercase">{attendance}</span>
                    </div>
                    <div className="p-5 flex justify-between items-center">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Session</span>
                      <span className="text-sm font-black text-blue-700 uppercase">{session}</span>
                    </div>
                  </div>
                  
                  <button 
                    onClick={handleSaveRegistration}
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-black py-5.5 rounded-2xl shadow-2xl shadow-green-100 active:scale-95 transition-all text-lg"
                  >
                    {isUpdating ? 'Update Registration' : 'Submit Registration'}
                  </button>
                </div>
              )}

              {step === RegistrationStep.SUCCESS && (
                <div className="p-12 text-center animate-in zoom-in duration-600">
                  <div className="w-24 h-24 bg-green-50 text-green-600 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-inner rotate-3">
                    <CheckCircleIcon className="w-14 h-14" />
                  </div>
                  <h2 className="text-3xl font-black mb-3 text-slate-900">{isUpdating ? 'Updated.' : 'Recorded.'}</h2>
                  <p className="text-slate-500 text-sm mb-12 font-medium leading-relaxed px-4">The **Events1** datasheet has been updated. A verification link has been simulation-sent.</p>
                  
                  <div className="space-y-4">
                    <button 
                      onClick={handleSimulateVerification}
                      className="w-full bg-slate-900 text-white font-black py-4.5 rounded-2xl shadow-lg hover:bg-black transition-all flex items-center justify-center gap-3 active:scale-95"
                    >
                      Verify Now <CheckCircleIcon className="w-5 h-5 text-green-400" />
                    </button>
                    <button onClick={resetForm} className="w-full py-4 text-slate-400 text-[10px] font-black uppercase tracking-[0.3em] hover:text-blue-600 transition-colors">Return to Start</button>
                  </div>
                </div>
              )}

              {error && <div className="p-4 bg-red-50 text-red-700 text-[10px] font-black uppercase tracking-widest border-t border-red-100 flex items-center justify-center gap-2"><ExclamationCircleIcon className="w-4 h-4" /> {error}</div>}
            </div>
          </div>
        ) : (
          <div className="max-w-6xl w-full animate-in fade-in duration-500">
            {!isAuthorized ? (
              <div className="max-w-md mx-auto bg-white p-12 rounded-[2.5rem] shadow-2xl text-center border border-slate-100">
                <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center mx-auto mb-8 border border-slate-100">
                  <LockClosedIcon className="w-10 h-10 text-blue-900/30" />
                </div>
                <h2 className="text-3xl font-black mb-3 text-slate-900 tracking-tight">Events1 Sheet</h2>
                <p className="text-slate-500 text-sm mb-10 font-medium">Access to the clcphilippines.org datasheet requires the Secretariat unlock code.</p>
                <form onSubmit={handleAuth} className="space-y-5">
                  <input 
                    type="password" 
                    value={authInput} 
                    onChange={(e) => setAuthInput(e.target.value)} 
                    placeholder="Enter Secret Code" 
                    className="w-full p-5 bg-slate-50 border-2 border-slate-100 rounded-2xl text-center font-black tracking-[0.6em] outline-none focus:border-blue-600 transition-all text-lg"
                  />
                  <button type="submit" className="w-full bg-slate-900 text-white font-black py-5 rounded-2xl shadow-2xl hover:bg-black transition-all active:scale-[0.98]">Authenticate Access</button>
                </form>
                <p className="mt-8 text-[9px] font-black text-slate-300 uppercase tracking-[0.2em]">Restricted to National Secretariat Personnel</p>
              </div>
            ) : (
              <div className="bg-white rounded-[2rem] shadow-2xl overflow-hidden border border-slate-200">
                <div className="p-8 border-b border-slate-100 bg-slate-50/50 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <TableCellsIcon className="w-5 h-5 text-blue-700" />
                      <h2 className="text-2xl font-black text-slate-900 tracking-tight">Events1 Datasheet</h2>
                    </div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Database: secretariat@clcphilippines.org</p>
                  </div>
                  <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-1 min-w-[240px]">
                      <MagnifyingGlassIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        value={searchTerm} 
                        onChange={(e) => setSearchTerm(e.target.value)} 
                        placeholder="Search records..." 
                        className="pl-12 pr-6 py-3.5 bg-white border border-slate-200 rounded-2xl text-sm font-bold outline-none focus:ring-4 ring-blue-500/10 focus:border-blue-600 w-full"
                      />
                    </div>
                    <button 
                      onClick={exportToCSV}
                      disabled={filteredRecords.length === 0}
                      className="flex items-center gap-2 bg-blue-700 text-white px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-800 transition-all disabled:opacity-30 shadow-lg shadow-blue-100"
                    >
                      <ArrowDownTrayIcon className="w-4 h-4" /> Export CSV
                    </button>
                    <button 
                      onClick={handleClearData}
                      className="p-3.5 bg-white border border-slate-200 text-slate-400 hover:text-red-600 hover:border-red-100 rounded-2xl transition-all shadow-sm"
                      title="Clear Database"
                    >
                      <TrashIcon className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-slate-50/80 border-b border-slate-100">
                      <tr>
                        <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Registrant</th>
                        <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Email & Contact</th>
                        <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Mode</th>
                        <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Session</th>
                        <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] text-center">Verified</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {filteredRecords.length > 0 ? filteredRecords.map((r, i) => (
                        <tr key={i} className="group hover:bg-blue-50/30 transition-colors">
                          <td className="px-8 py-6">
                            <p className="text-sm font-black text-slate-900 group-hover:text-blue-900 transition-colors">{r.name}</p>
                            <p className="text-[9px] font-black text-slate-400 group-hover:text-blue-400 uppercase mt-1 tracking-widest">{r.departmentTitle || 'CLCP Member'}</p>
                          </td>
                          <td className="px-8 py-6">
                            <p className="text-xs font-bold text-slate-600 mb-0.5">{r.email}</p>
                            <p className="text-[10px] font-mono text-slate-400">{r.phone}</p>
                          </td>
                          <td className="px-8 py-6">
                            <span className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest ${r.attendance === 'Zoom' ? 'bg-indigo-50 text-indigo-700 border border-indigo-100' : 'bg-emerald-50 text-emerald-700 border border-emerald-100'}`}>
                              {r.attendance}
                            </span>
                          </td>
                          <td className="px-8 py-6">
                            <p className="text-xs font-black text-slate-700 uppercase tracking-tighter">{r.session}</p>
                          </td>
                          <td className="px-8 py-6 text-center">
                            <span className={`inline-flex items-center justify-center w-9 h-9 rounded-xl font-black transition-all ${r.confirmation === 'Y' ? 'bg-green-100 text-green-700 border border-green-200' : 'bg-red-50 text-red-600 border border-red-100 opacity-60'}`}>
                              {r.confirmation}
                            </span>
                          </td>
                        </tr>
                      )) : (
                        <tr>
                          <td colSpan={5} className="px-8 py-20 text-center">
                            <div className="flex flex-col items-center">
                              <MagnifyingGlassIcon className="w-12 h-12 text-slate-200 mb-4" />
                              <p className="text-sm font-bold text-slate-300">No records found matching your search.</p>
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      <footer className="py-8 bg-white border-t border-slate-100">
        <div className="max-w-6xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[9px] font-black text-slate-300 uppercase tracking-[0.4em]">Christian Life Community Philippines</p>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(34,197,94,0.6)]" />
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Live: Secretariat Sync</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full shadow-[0_0_8px_rgba(59,130,246,0.4)]" />
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Disk Storage: Active</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
