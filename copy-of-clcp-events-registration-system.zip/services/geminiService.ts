
import { GoogleGenAI, Type } from "@google/genai";
import { ContactData, RegistrationRecord } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Key for local storage persistence
const STORAGE_KEY = 'clcp_events1_data';

/**
 * Loads records from localStorage or returns empty Map
 */
function loadFromDisk(): Map<string, RegistrationRecord> {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (!saved) return new Map();
  try {
    const parsed = JSON.parse(saved);
    return new Map(Object.entries(parsed));
  } catch (e) {
    console.error("Failed to parse disk data", e);
    return new Map();
  }
}

/**
 * Saves the current state of the map to localStorage
 */
function saveToDisk(map: Map<string, RegistrationRecord>) {
  const obj = Object.fromEntries(map);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(obj));
}

// Initial state from disk
let events1Sheet: Map<string, RegistrationRecord> = loadFromDisk();

/**
 * Returns all records currently in the Events1 datasheet.
 */
export function getAllRegistrations(): RegistrationRecord[] {
  events1Sheet = loadFromDisk(); // Refresh from disk
  return Array.from(events1Sheet.values()).sort((a, b) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

/**
 * Checks if a user with this email is already in the Events1 datasheet.
 */
export async function checkExistingRegistration(email: string): Promise<RegistrationRecord | null> {
  events1Sheet = loadFromDisk();
  const normalized = email.toLowerCase().trim();
  return events1Sheet.get(normalized) || null;
}

/**
 * Simulates checking the secretariat@clcphilippines.org contact database.
 */
export async function lookupContact(email: string): Promise<ContactData | null> {
  const normalized = email.toLowerCase().trim();
  
  // Hardcoded test cases for immediate feedback
  if (normalized === 'member@clcp.org') {
    return {
      name: "Juan Dela Cruz",
      email: "member@clcp.org",
      phone: "0917-123-4567",
      departmentTitle: "Formation Ministry",
      source: "secretariat@clcphilippines.org"
    };
  }
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Search for email "${normalized}" in the CLC Philippines Secretariat contacts. 
      If found, return name and phone. If not found, return found: false.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            found: { type: Type.BOOLEAN },
            contact: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                phone: { type: Type.STRING },
                departmentTitle: { type: Type.STRING }
              }
            }
          },
          required: ["found"]
        }
      }
    });

    const data = JSON.parse(response.text || '{}');
    if (data.found) {
      return {
        ...data.contact,
        email: normalized,
        source: "secretariat@clcphilippines.org"
      };
    }
    return null;
  } catch (error) {
    console.error("Lookup error:", error);
    return null;
  }
}

/**
 * Saves or updates a record in the Events1 datasheet and persists it.
 */
export async function saveToEvents1(record: RegistrationRecord) {
  events1Sheet = loadFromDisk();
  events1Sheet.set(record.email.toLowerCase().trim(), record);
  saveToDisk(events1Sheet);
  return { success: true };
}

/**
 * Simulates the confirmation 'Y' update when a user verifies their attendance.
 */
export async function verifyAttendance(email: string) {
  events1Sheet = loadFromDisk();
  const key = email.toLowerCase().trim();
  const existing = events1Sheet.get(key);
  if (existing) {
    const updated = { ...existing, confirmation: 'Y' as const };
    events1Sheet.set(key, updated);
    saveToDisk(events1Sheet);
    return true;
  }
  return false;
}

/**
 * Clears the local database for testing
 */
export function clearAllData() {
  events1Sheet.clear();
  localStorage.removeItem(STORAGE_KEY);
}
