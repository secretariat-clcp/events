
export type AttendanceType = 'In Person' | 'Zoom' | '';
export type SessionType = 'AM Session' | 'PM Session' | 'Both Sessions' | '';

export interface ContactData {
  name: string;
  email: string;
  phone: string;
  departmentTitle?: string;
  source?: string;
}

export interface RegistrationRecord extends ContactData {
  attendance: AttendanceType;
  session: SessionType;
  confirmation: 'Y' | 'N';
  id: string;
  timestamp: string;
}

export enum RegistrationStep {
  EMAIL_INPUT = 0,
  VERIFY_CONTACT = 1,
  MANUAL_ENTRY = 2,
  PREFERENCES = 3,
  SUMMARY = 4,
  SUCCESS = 5,
  ALREADY_REGISTERED = 6
}
